
let products = {}; // Declare products globally
let cart = JSON.parse(localStorage.getItem('cart')) || []; // Retrieve cart from localStorage

// Add products to cart
function addToCart(id, name, price, image) {
    const existingItem = cart.find(item => item.name === name);
    if (existingItem) {
        existingItem.quantity++;
        existingItem.totalPrice += price;
    } else {
        cart.push({id, name, price, totalPrice: price, image, quantity: 1 });
    }
    localStorage.setItem('cart', JSON.stringify(cart)); // Save updated cart
    updateCartCount(); // Update cart counter
}

// Update cart count
function updateCartCount() {
    const cartCount = document.getElementById('cartCount');
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    if (cartCount) {
        cartCount.textContent = totalItems;
    }
}

// Initialize cart count on page load
document.addEventListener('DOMContentLoaded', () => {
    updateCartCount();
});
// Call this function after modifying the cart
// addToCart(name, price, image);


//buynow
function buyNow(id, name, price, image) {
    const selectedProduct = { id, name, price, image, quantity: 1, totalPrice: price };
    localStorage.setItem('buyNowProduct', JSON.stringify(selectedProduct)); // Save selected product to localStorage
    window.location.href = './order.html'; // Redirect to order page
}




// Function to redirect to the cart page
function showCart() {
    localStorage.setItem('cart', JSON.stringify(cart)); // Ensure cart is saved
    window.location.href = './cart.html'; // Redirect to cart page
}

// Function to render products for a category
function renderProducts(category) {
    const container = document.getElementById(category);
    container.innerHTML = ''; // Clear existing content
    if (!products[category]) return; // Ensure category data is available

    products[category].forEach((product) => {
        const productCard = `
        <div class="product-card">
            <img src="${product.image}" alt="${product.name}">
            <div class="product-info">
                <h3>${product.name}</h3>
                <p>${product.description}</p>
                <div class="price">$${product.price}</div>
                <div class="button-container">
                    <button onclick="addToCart('${product.id}','${product.name}', ${product.price}, '${product.image}')">Add to Cart</button>
                    <button onclick="buyNow('${product.id}','${product.name}', ${product.price}, '${product.image}')">Buy Now</button>
                </div>
            </div>
        </div>
    `;
    
    
        container.innerHTML += productCard;
    });
}

// Fetch products from JSON
fetch('./products.jsp')
    .then(response => response.json())
    .then(data => {
        products = data; // Assign data to products
        renderProducts('mens'); // Render Men's category
        renderProducts('womens'); // Render Women's category
        showCategory('mens'); // Show default category
		console.log(data)
    })
    .catch(error => console.error('Error fetching products:', error));

// Function to show a specific category
function showCategory(category) {
    // Hide all categories
    document.querySelectorAll('.products').forEach((section) => {
        section.classList.remove('active');
    });
    // Show the selected category
    const selectedCategory = document.getElementById(category);
    if (selectedCategory) {
        selectedCategory.classList.add('active');
    }

    // Remove active class from all buttons
    document.querySelectorAll('.category-buttons button').forEach((button) => {
        button.classList.remove('active');
    });

    // Add active class to the clicked button
    const button = document.querySelector(`[onclick="showCategory('${category}')"]`);
    if (button) {
        button.classList.add('active');
    }
}
