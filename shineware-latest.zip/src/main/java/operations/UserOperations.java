package operations;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class UserOperations {
	public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();

        try {
    		DatabaseConnector connector = new DatabaseConnector();
    		Connection con= connector.getConnection();
            // SQL query to fetch all product data
            String sql = "SELECT * FROM tbl_product";
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            // Iterate through the result set and populate the Product list
            while (rs.next()) {
                Product product = new Product(
                    rs.getInt("product_id"),
                    rs.getString("product_name"),
                    rs.getString("product_brand"),
                    rs.getString("product_description"),
                    rs.getString("product_category_name"),
                    rs.getString("product_image"),
                    rs.getInt("product_price"),
                    rs.getInt("product_discount"),
                    rs.getInt("product_stock"),
                    rs.getString("product_stock_status"),
                    rs.getBoolean("product_status")
                );

                products.add(product);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return products;
    }
	public boolean saveOrder(User user, List<Product> products, double totalPrice, String orderDate, String deliveryDate) {
        Connection con = null;
        PreparedStatement orderStmt = null;
        PreparedStatement itemStmt = null;
        ResultSet generatedKeys = null;

        try {
        	DatabaseConnector connector = new DatabaseConnector();
    		con= connector.getConnection();
    		con.setAutoCommit(false); // Start transaction

            // Insert into orders table
            String orderSQL = "INSERT INTO tbl_orders (customer_name, customer_phone, customer_address, order_date, delivery_date, total_price) VALUES (?, ?, ?, ?, ?, ?)";
            orderStmt = con.prepareStatement(orderSQL, Statement.RETURN_GENERATED_KEYS);
            orderStmt.setString(1, user.getName());
            orderStmt.setString(2, user.getPhone());
            orderStmt.setString(3, user.getAddress());
            orderStmt.setString(4, orderDate);
            orderStmt.setString(5, deliveryDate);
            orderStmt.setDouble(6, totalPrice);
            orderStmt.executeUpdate();

            // Get the generated order ID
            generatedKeys = orderStmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                int orderId = generatedKeys.getInt(1);

                // Insert into order_items table
                String itemSQL = "INSERT INTO order_items (order_id, product_name, quantity, price, total_price) VALUES (?, ?, ?, ?, ?)";
                itemStmt = con.prepareStatement(itemSQL);

                for (Product product : products) {
                    itemStmt.setInt(1, orderId);
                    itemStmt.setString(2, product.getProductTitle());
                    itemStmt.setInt(3, product.getProductStock()); // Quantity
                    itemStmt.setDouble(4, product.getProductPrice());
                    itemStmt.setDouble(5, product.getProductPrice() * product.getProductStock()); // Total price
                    itemStmt.addBatch();
                }
                itemStmt.executeBatch();
            }

            con.commit(); // Commit transaction
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            try {
                if (con != null) con.rollback(); // Rollback on error
            } catch (Exception rollbackEx) {
                rollbackEx.printStackTrace();
            }
        } finally {
            try {
                if (generatedKeys != null) generatedKeys.close();
                if (orderStmt != null) orderStmt.close();
                if (itemStmt != null) itemStmt.close();
                if (con != null) con.close();
            } catch (Exception closeEx) {
                closeEx.printStackTrace();
            }
        }

        return false;
    }
}
