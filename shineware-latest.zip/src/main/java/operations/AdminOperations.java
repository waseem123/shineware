package operations;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
 
public class AdminOperations {
	public Admin loginAdmin(String adminMobile,String adminPassword) {
		DatabaseConnector connector = new DatabaseConnector();
		Connection con= connector.getConnection();
		Admin admin = new Admin();
		String sql = "SELECT admin_id,admin_name,admin_mobile_no FROM tbl_admin WHERE admin_mobile_no=? and admin_password=?";
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1,adminMobile);
			ps.setString(2, adminPassword);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				admin.setAdminId(rs.getInt(1));
				admin.setAdminName(rs.getString(2));
				admin.setAdminMobile(rs.getString(3));
			}
			return admin;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return admin;
		}
		
	}
	
	public boolean saveProduct(Product product) {
        boolean isSaved = false;

        String insertQuery = "INSERT INTO tbl_product (product_name, product_brand, product_description, " +
                "product_category_name, product_image, product_price, product_discount, product_stock, " +
                "product_stock_status, product_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
        	DatabaseConnector connector = new DatabaseConnector();
    		Connection con= connector.getConnection();
        
             PreparedStatement pstmt = con.prepareStatement(insertQuery); 

            // Set values for the prepared statement
            pstmt.setString(1, product.getProductTitle());
            pstmt.setString(2, product.getProductBrand());
            pstmt.setString(3, product.getProductDescription());
            pstmt.setString(4, product.getProductCategory());
            pstmt.setString(5, product.getProductImagePath());
            pstmt.setInt(6, product.getProductPrice());
            pstmt.setInt(7, product.getProductDiscount());
            pstmt.setInt(8, product.getProductStock());
            pstmt.setString(9, product.getProductStockStatus());
            pstmt.setBoolean(10, product.isProductStatus());

            // Execute the query
            int rowsAffected = pstmt.executeUpdate();

            // Check if the product was inserted successfully
            if (rowsAffected > 0) {
                isSaved = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return isSaved;
    }
	
	// Fetch All Products Method
    public List<Product> getAllProducts() {
    	DatabaseConnector connector = new DatabaseConnector();
		Connection con= connector.getConnection();
        List<Product> productList = new ArrayList<>();

        String selectQuery = "SELECT * FROM tbl_product";

        try (
        		
             PreparedStatement pstmt = con.prepareStatement(selectQuery);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Product product = new Product();
                product.setProductId(rs.getInt("product_id"));
                product.setProductTitle(rs.getString("product_name"));
                product.setProductBrand(rs.getString("product_brand"));
                product.setProductDescription(rs.getString("product_description"));
                product.setProductCategory(rs.getString("product_category_name"));
                product.setProductImagePath(rs.getString("product_image"));
                product.setProductPrice(rs.getInt("product_price"));
                product.setProductDiscount(rs.getInt("product_discount"));
                product.setProductStock(rs.getInt("product_stock"));
                product.setProductStockStatus(rs.getString("product_stock_status"));
                product.setProductStatus(rs.getBoolean("product_status"));

                productList.add(product);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return productList;
    }
    
    public Product getProductById(int productId) {
        Product product = new Product();
        try  {
        	DatabaseConnector connector = new DatabaseConnector();
    		Connection con= connector.getConnection();
            String sql = "SELECT * FROM tbl_product WHERE product_id = ?";
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, productId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                product = new Product(
                    rs.getInt("product_id"),
                    rs.getString("product_name"),
                    rs.getString("product_brand"),
                    rs.getString("product_description"),
                    rs.getString("product_category_name"),
                    rs.getString("product_image"),
                    rs.getInt("product_price"),
                    rs.getInt("product_discount"),
                    rs.getInt("product_stock"),
                    rs.getString("product_stock_status"),
                    rs.getBoolean("product_status")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return product;
    }
    
    public boolean editProduct(Product product) {
        boolean isUpdated = false;
        try {
        	DatabaseConnector connector = new DatabaseConnector();
    		Connection con= connector.getConnection();
            String sql = "UPDATE tbl_product SET product_name = ?, product_brand = ?, product_description = ?, " +
                         "product_category_name = ?, product_price = ?, product_discount = ?, product_stock = ?, " +
                         "product_status = ? WHERE product_id = ?";
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, product.getProductTitle());
            pstmt.setString(2, product.getProductBrand());
            pstmt.setString(3, product.getProductDescription());
            pstmt.setString(4, product.getProductCategory());
            pstmt.setInt(5, product.getProductPrice());
            pstmt.setInt(6, product.getProductDiscount());
            pstmt.setInt(7, product.getProductStock());
            pstmt.setBoolean(8, product.isProductStatus());
            pstmt.setInt(9, product.getProductId());

            isUpdated = pstmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isUpdated;
    }
    
    public boolean deleteProduct(int productId) {
    	boolean isDeleted = false;
        try {
        	DatabaseConnector connector = new DatabaseConnector();
    		Connection con= connector.getConnection();
            String sql = "DELETE FROM tbl_product WHERE product_id = ?";
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, productId);

            isDeleted = pstmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isDeleted;
    }

}
