package operations;
import java.sql.*;

public class DatabaseConnector {
	Connection con = null;
	public Connection getConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db_shineware","root","admin");
			
			System.out.println("Connection Success");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Connection Failure - "+e.getMessage());
			e.printStackTrace();
		}
		return con;
	}
}
