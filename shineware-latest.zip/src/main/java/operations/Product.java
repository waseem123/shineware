package operations;

public class Product {
	private int productId;
	private String productTitle;
	private String productBrand;
	private String productDescription;
	private String productCategory;
	private String productImagePath;
	private int productPrice;
	private int productDiscount;
	private int productStock;
	private String productStockStatus;
	private boolean productStatus;
	private int productQuantity; 
	
	public Product() {
		this.productStock = 100;
		this.productStatus = true;
		this.productStockStatus = "IN";
	}
	
	public Product(int productId,int productQuantity) {
		this.productStock = 100;
		this.productStatus = true;
		this.productStockStatus = "IN";
	}
	
	
	
	public Product(String productTitle, String productBrand, String productDescription, String productCategory,
			String productImagePath, int productPrice, int productDiscount) {
		super();
		this.productTitle = productTitle;
		this.productBrand = productBrand;
		this.productDescription = productDescription;
		this.productCategory = productCategory;
		this.productImagePath = productImagePath;
		this.productPrice = productPrice;
		this.productDiscount = productDiscount;
		this.productStock = 100;
		this.productStatus = true;
		this.productStockStatus = "IN";
	}



	public Product(String productTitle, String productBrand, String productDescription, String productCategory,
			String productImagePath, int productPrice, int productDiscount, int productStock, String productStockStatus,
			boolean productStatus) {
		super();
		this.productTitle = productTitle;
		this.productBrand = productBrand;
		this.productDescription = productDescription;
		this.productCategory = productCategory;
		this.productImagePath = productImagePath;
		this.productPrice = productPrice;
		this.productDiscount = productDiscount;
		this.productStock = productStock;
		this.productStockStatus = productStockStatus;
		this.productStatus = productStatus;
	}



	public Product(int productId, String productTitle, String productBrand, String productDescription,
			String productCategory, String productImagePath, int productPrice, int productDiscount, int productStock,
			String productStockStatus, boolean productStatus) {
		this.productId = productId;
		this.productTitle = productTitle;
		this.productBrand = productBrand;
		this.productDescription = productDescription;
		this.productCategory = productCategory;
		this.productImagePath = productImagePath;
		this.productPrice = productPrice;
		this.productDiscount = productDiscount;
		this.productStock = productStock;
		this.productStockStatus = productStockStatus;
		this.productStatus = productStatus;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductTitle() {
		return productTitle;
	}
	public void setProductTitle(String productTitle) {
		this.productTitle = productTitle;
	}
	public String getProductBrand() {
		return productBrand;
	}
	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public String getProductImagePath() {
		return productImagePath;
	}
	public void setProductImagePath(String productImagePath) {
		this.productImagePath = productImagePath;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	public int getProductDiscount() {
		return productDiscount;
	}
	public void setProductDiscount(int productDiscount) {
		this.productDiscount = productDiscount;
	}
	public int getProductStock() {
		return productStock;
	}
	public void setProductStock(int productStock) {
		this.productStock = productStock;
	}
	public String getProductStockStatus() {
		return productStockStatus;
	}
	public void setProductStockStatus(String productStockStatus) {
		this.productStockStatus = productStockStatus;
	}
	public boolean isProductStatus() {
		return productStatus;
	}
	public void setProductStatus(boolean productStatus) {
		this.productStatus = productStatus;
	}
	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	
}
